package com.cts.college.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@Table(name = "college")
@AllArgsConstructor
@NoArgsConstructor
public class College {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "collegeId")
	int id;
	@Column(name = "collegeName")
	String name;
	@Column(name = "collegeLocation")
	String location;
}
