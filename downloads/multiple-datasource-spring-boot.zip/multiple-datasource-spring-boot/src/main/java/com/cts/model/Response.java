package com.cts.model;

import lombok.Data;

import java.util.List;

import com.cts.college.entity.College;
import com.cts.student.entity.Student;

@Data
public class Response {
    List<Student> students;
    List<College> colleges;
}
