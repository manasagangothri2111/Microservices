package com.cts;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.cts.college.entity.College;
import com.cts.college.repository.CollegeRepository;
import com.cts.student.entity.Student;
import com.cts.student.repository.StudentRepository;

import lombok.RequiredArgsConstructor;

@SpringBootApplication
@RequiredArgsConstructor
public class SpringBootMultipleDatasourceApplication {

	private final CollegeRepository collegeRepository;

	private final StudentRepository studentRepository;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMultipleDatasourceApplication.class, args);
	}

	@Bean
	CommandLineRunner commandLineRunner() {
		return args -> {

			College college = new College(10, "JNTU", "HYD");
			collegeRepository.save(college);

			Student student = new Student(1, "Rani", "22");
			studentRepository.save(student);

		};
	}
}
