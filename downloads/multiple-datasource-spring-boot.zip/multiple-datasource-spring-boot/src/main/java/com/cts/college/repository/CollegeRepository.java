package com.cts.college.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.college.entity.College;

public interface CollegeRepository extends JpaRepository<College, Integer> {
}
